#!/usr/bin/env python3

import subprocess
from pathlib import Path

input_file = input("Enter the path of the confirmed host file: ").strip()

if not Path(input_file).is_file():
    print("File not found!")
    exit(1)

output_file = "assetfinderN_output.txt"

# Create output file immediately
with open(output_file, "w") as f:
    pass

try:
    with open(input_file, "r") as f:
        domains = [line.strip() for line in f if line.strip()]

    with open(output_file, "a") as output:
        for domain in domains:
            print(f"[+] Running Assetfinder on: {domain}")

            process = subprocess.Popen(
                ["assetfinder", "--subs-only", domain],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True
            )

            for hostname in process.stdout:
                output.write(hostname)
                output.flush()

            process.wait()

except KeyboardInterrupt:
    print("\n[!] Cancelled.")

finally:
    print(f"[+] Results saved to: {output_file}")