
import os
import json
import subprocess
import tempfile

def get_file(prompt):
    while True:
        path = input(prompt).strip().strip('"')
        if os.path.isfile(path):
            return os.path.abspath(path)
        print("File not found. Try again.")


domains_file = get_file("Path to confirmed_host.txt: ")
wordlist_file = get_file("Path to subdomain_candidate.txt: ")
resolvers_file = get_file("Path to resolvers.txt: ")

candidates_file = "sub_added_dom.txt"
output_file = "massdnsN_output.txt"

record_types = [
    "A", "AAAA", "AFSDB", "APL", "CAA", "CDNSKEY", "CDS",
    "CERT", "CNAME", "DHCID", "DLV", "DNAME", "DNSKEY",
    "DS", "EUI48", "EUI64", "HINFO", "HIP", "HTTPS",
    "IPSECKEY", "ISDN", "KX", "LOC", "LP", "MB", "MD",
    "MF", "MG", "MINFO", "MR", "MX", "NAPTR", "NS",
    "NSEC", "NSEC3", "NSEC3PARAM", "OPENPGPKEY", "PTR",
    "PX", "RP", "RRSIG", "RT", "SIG", "SMIMEA", "SOA",
    "SPF", "SRV", "SSHFP", "SVCB", "TA", "TKEY", "TLSA",
    "TSIG", "TXT", "URI", "WKS", "ZONEMD", "ANY"
]

record_types = list(dict.fromkeys(record_types))

process = None
seen_records = set()
seen_hostnames = set()
temp_files = {}
temp_paths = {}
cancelled = False


def get_answers(obj):
    """Extract answer records only from MassDNS JSON output."""

    if not isinstance(obj, dict):
        return []

    data = obj.get("data", {})

    if isinstance(data, dict):
        answers = data.get("answers", [])
    else:
        answers = obj.get("answers", [])

    if not isinstance(answers, list):
        return []

    return [
        record for record in answers
        if isinstance(record, dict)
        and record.get("type")
        and record.get("name")
        and "data" in record
    ]


def format_record(record):
    name = record.get("name", "")
    ttl = record.get("ttl", "")
    rclass = record.get("class", "IN")
    rtype = str(record.get("type", "UNKNOWN")).upper()
    data = record.get("data", "")

    return f"{name} {ttl} {rclass} {rtype} {data}\n"


def save_grouped_output():
    """Rewrite output in grouped format."""

    with open(output_file, "w", buffering=1) as output:

        for rtype in record_types + ["MIX"]:
            output.write(f"{rtype} record:\n")

            path = temp_paths.get(rtype)

            if path and os.path.exists(path):
                with open(path) as source:
                    for line in source:
                        output.write(line)

            output.write("\n")
            output.flush()

        output.write("hostnames:\n")

        for hostname in sorted(seen_hostnames):
            output.write(hostname.rstrip(".") + "\n")

        output.flush()


# Create candidates file immediately
print(f"\nCreating {candidates_file}...")

try:
    with open(domains_file) as domains, \
         open(wordlist_file) as words, \
         open(candidates_file, "w", buffering=1) as output:

        wordlist = [
            line.strip().strip(".")
            for line in words
            if line.strip()
        ]

        for domain in domains:
            domain = domain.strip().strip(".")

            if not domain:
                continue

            for word in wordlist:
                output.write(f"{word}.{domain}\n")
                output.flush()

except KeyboardInterrupt:
    print("\nCancelled during candidate generation.")
    print(f"Partial candidates saved: {candidates_file}")
    raise SystemExit


print("Candidates generated.")

# Count candidates
with open(candidates_file) as file:
    total_candidates = sum(1 for line in file if line.strip())

print(f"Total candidates: {total_candidates}")


# Create output file immediately
with open(output_file, "w", buffering=1) as output:
    output.write("DNS scan results\n\n")

print(f"Output created: {output_file}")


try:
    temp_dir = tempfile.TemporaryDirectory()

    # Create temporary category files
    for rtype in record_types + ["MIX"]:
        path = os.path.join(temp_dir.name, f"{rtype}.txt")
        temp_paths[rtype] = path
        temp_files[rtype] = open(path, "w", buffering=1)

    for query_type in record_types:

        if cancelled:
            break

        print(f"\nChecking {query_type} records...")

        response_count = 0
        record_count = 0

        process = subprocess.Popen(
            [
                "massdns",
                "-r", resolvers_file,
                "-t", query_type,
                "-o", "J",
                "--flush",
                candidates_file
            ],
            stdout=subprocess.PIPE,
            stderr=None,
            text=True,
            bufsize=1
        )

        try:
            for line in process.stdout:

                response_count += 1

                try:
                    obj = json.loads(line)

                    # Ignore unsuccessful DNS responses
                    status = obj.get("status")

                    if status not in (None, "NOERROR"):
                        continue

                    answers = get_answers(obj)

                    # No answer records means no confirmed hostname
                    if not answers:
                        continue

                    # Save the queried hostname as available
                    hostname = obj.get("name", "").strip()

                    if hostname:
                        seen_hostnames.add(hostname)

                    for record in answers:

                        rtype = str(
                            record.get("type", "UNKNOWN")
                        ).upper()

                        category = (
                            rtype if rtype in temp_files else "MIX"
                        )

                        formatted = format_record(record)
                        key = category + "|" + formatted

                        if key in seen_records:
                            continue

                        seen_records.add(key)

                        # Save category immediately
                        temp_files[category].write(formatted)
                        temp_files[category].flush()

                        record_count += 1

                        # Save live result immediately
                        with open(output_file, "a", buffering=1) as live:
                            live.write(f"[{category}] {formatted}")
                            live.flush()

                except (json.JSONDecodeError, TypeError, AttributeError):
                    continue

            process.wait()

        except KeyboardInterrupt:
            cancelled = True
            print("\nCancelled! Preserving collected results...")

            if process and process.poll() is None:
                process.terminate()
                process.wait()

            break

        print(
            f"{query_type} finished | "
            f"Responses: {response_count} | "
            f"Records: {record_count}"
        )

        if process.returncode != 0:
            print(
                f"MassDNS returned error for {query_type} "
                f"(exit code {process.returncode})."
            )

except KeyboardInterrupt:
    cancelled = True
    print("\nCancelled! Preserving collected results...")

finally:
    # Close temporary category files
    for file in temp_files.values():
        file.close()

    # Write final grouped output
    if temp_paths:
        save_grouped_output()
        temp_dir.cleanup()

    print(f"\nCandidates: {candidates_file}")
    print(f"Results: {output_file}")

    if cancelled:
        print("Partial results saved.")
    else:
        print("MassDNS scanning finished.")
