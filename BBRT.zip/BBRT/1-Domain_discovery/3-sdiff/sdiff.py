
import ipaddress
import re


def read_file(path):
    with open(path, "r", encoding="utf-8") as file:
        return [line.strip() for line in file if line.strip()]


def normalize_httpx(line):
    line = line.strip()

    # Detect protocol
    protocol = None

    if line.lower().startswith("https://"):
        protocol = "https"
        line = line[8:]
    elif line.lower().startswith("http://"):
        protocol = "http"
        line = line[7:]

    # Remove path, query, and fragment
    host = re.split(r"[/?#]", line, maxsplit=1)[0]

    # Check whether a port exists
    if host.startswith("["):
        match = re.fullmatch(r"\[([0-9a-fA-F:.]+)\](?::(\d+))?", host)
        if not match:
            return None
        ip = match.group(1)
        port = match.group(2)
    else:
        if host.count(":") > 1:
            return None

        if ":" in host:
            ip, port = host.rsplit(":", 1)
        else:
            ip = host
            port = None

    # Validate IP
    try:
        ip = str(ipaddress.ip_address(ip))
    except ValueError:
        return None

    # Assign default port
    if port is None:
        if protocol == "http":
            port = "80"
        elif protocol == "https":
            port = "443"
        else:
            return None

    # Validate port
    try:
        port_num = int(port)
        if not 1 <= port_num <= 65535:
            return None
    except ValueError:
        return None

    return f"{ip}:{port_num}"


def main():
    massfill_path = input("Enter Massfill output path: ").strip()
    httpx_path = input("Enter httpx output path: ").strip()

    try:
        massfill_lines = read_file(massfill_path)
        httpx_lines = read_file(httpx_path)
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
        return
    except OSError as e:
        print(f"File error: {e}")
        return

    # Extract Massfill IP:PORT
    massfill_set = set()

    for line in massfill_lines:
        try:
            ip, port = line.rsplit(":", 1)
            ip = str(ipaddress.ip_address(ip))
            port = int(port)

            if 1 <= port <= 65535:
                massfill_set.add(f"{ip}:{port}")
        except ValueError:
            continue

    # Extract httpx IP:PORT
    httpx_set = set()
    abnormal_comments = []

    for line in httpx_lines:
        result = normalize_httpx(line)

        if result is None:
            abnormal_comments.append(
                f"Abnormal format in httpx ouput: {line}"
            )
        else:
            httpx_set.add(result)

    # Compare both sets
    common = massfill_set & httpx_set
    only_massfill = massfill_set - httpx_set
    only_httpx = httpx_set - massfill_set

    # Final output
    results = sorted(only_massfill)

    comments = abnormal_comments[:]

    for item in sorted(only_httpx):
        comments.append(
            f"be in httpx but not be in the massfill: {item}"
        )

    output_path = "sdiff_output.txt"

    with open(output_path, "w", encoding="utf-8") as file:
        for item in results:
            file.write(item + "\n")

        if comments:
            file.write("\n# Comments:\n")
            for comment in comments:
                file.write(comment + "\n")

    print("\nComparison completed!")
    print(f"Common IP:PORT removed: {len(common)}")
    print(f"Only in Massfill: {len(only_massfill)}")
    print(f"Only in httpx: {len(only_httpx)}")
    print(f"Abnormal formats: {len(abnormal_comments)}")
    print(f"Output saved to: {output_path}")


if __name__ == "__main__":
    main()
