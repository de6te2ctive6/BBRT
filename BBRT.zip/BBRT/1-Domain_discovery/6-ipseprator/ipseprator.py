
import ipaddress

file_path = input("Enter the path of the IP:PORT file: ")

ips = set()
ports = set()

with open(file_path, "r", encoding="utf-8") as file:
    for line in file:
        line = line.strip()

        if not line or ":" not in line:
            continue

        ip, port = line.rsplit(":", 1)

        try:
            ipaddress.ip_address(ip)
            port = int(port)

            if 1 <= port <= 65535:
                ips.add(ip)
                ports.add(port)

        except ValueError:
            continue

output_file = "ipseprator_output.txt"

with open(output_file, "w", encoding="utf-8") as file:
    file.write("ips:\n")
    file.write("\n".join(
        sorted(ips, key=lambda x: ipaddress.ip_address(x))
    ))

    file.write("\n\n")
    file.write("ports: " + ", ".join(map(str, sorted(ports))))

print(f"\nOutput saved to: {output_file}")
