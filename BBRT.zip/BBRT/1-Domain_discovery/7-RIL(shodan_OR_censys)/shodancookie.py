
import os
import time
import requests
from bs4 import BeautifulSoup

# Add your Shodan polito cookies in order
POLITO_COOKIES = [
    "polito place here 1",
    "polito place here 2",
    "PUT_POLITO_COOKIE_3_HERE",
]

# Adjustable delay between requests (seconds)
SLEEP_SECONDS = 10

INPUT_FILE = input(
    "Enter the path of your ipseprator output file: "
).strip().strip('"')

OUTPUT_FILE = "shodancookie_output.txt"


def extract_values(grid, label_text, tag_name):
    label = next(
        (
            item for item in grid.find_all("label")
            if item.get_text(" ", strip=True).casefold()
            == label_text.casefold()
        ),
        None
    )

    if not label:
        return []

    values = []

    for sibling in label.next_siblings:
        if getattr(sibling, "name", None) == "label":
            break

        if not getattr(sibling, "name", None):
            continue

        for element in sibling.find_all(tag_name):
            value = element.get_text(" ", strip=True)

            if value:
                values.append(value)

    return list(dict.fromkeys(values))


# Create output file immediately
with open(OUTPUT_FILE, "w", encoding="utf-8") as output:
    output.write("SHODAN COOKIE LOOKUP RESULTS\n")
    output.write("===========================\n\n")
    output.flush()


if not os.path.isfile(INPUT_FILE):
    print("File not found!")
    raise SystemExit

cookies = [
    cookie.strip()
    for cookie in POLITO_COOKIES
    if cookie.strip()
    and "PUT_POLITO_COOKIE" not in cookie
]

if not cookies:
    print("Please add at least one polito cookie.")
    raise SystemExit


with open(INPUT_FILE, "r", encoding="utf-8", errors="ignore") as f:
    ips = list(dict.fromkeys(
        line.strip() for line in f if line.strip()
    ))


sessions = []

for cookie in cookies:
    session = requests.Session()

    session.cookies.set(
        "polito",
        cookie,
        domain="shodan.io"
    )

    session.headers.update({
        "User-Agent": "Mozilla/5.0"
    })

    sessions.append(session)


try:
    for index, ip in enumerate(ips):

        # Rotate cookies in order
        session = sessions[index % len(sessions)]
        cookie_number = (index % len(sessions)) + 1

        url = f"https://www.shodan.io/host/{ip}"

        hostnames = []
        domains = []
        status = "Checked"

        try:
            response = session.get(url, timeout=20)
            response.raise_for_status()

            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            grid = soup.find(
                "div",
                class_="grid-table"
            )

            if grid:
                hostnames = extract_values(
                    grid, "Hostnames", "b"
                )

                domains = extract_values(
                    grid, "Domains", "a"
                )

                print(f"[+] Checked {ip} (Cookie {cookie_number})")

            else:
                status = "No grid-table"
                print(f"[!] No grid-table for {ip}")

        except requests.RequestException as e:
            status = "Request error"
            print(f"[!] Request error for {ip}: {e}")

        # Save this IP and its results immediately
        with open(OUTPUT_FILE, "a", encoding="utf-8") as output:

            output.write(f"\nIP: {ip} | Status: {status}\n")

            for hostname in hostnames:
                output.write(f"Hostname: {hostname}\n")

            for domain in domains:
                output.write(f"Domain: {domain}\n")

            output.flush()

        if hostnames or domains:
            print(f"[+] Results saved for {ip}")
        else:
            print(f"[-] No hostname/domain for {ip}")

        # Adjustable delay
        if index < len(ips) - 1:
            time.sleep(SLEEP_SECONDS)

except KeyboardInterrupt:
    print("\n[!] Stopped by user.")

finally:
    print(f"\nOutput saved to: {OUTPUT_FILE}")
