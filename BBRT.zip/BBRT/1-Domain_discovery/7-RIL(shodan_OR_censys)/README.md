install full pack:
sudo apt install python3-full -y

# Create venv in current directory
python3 -m venv ./shodan

# Activate it
source ./shodan/bin/activate

# Install required packages
pip install requests beautifulsoup4

# Run the script
python shodancookie.py

---

your idia is good, but with polito won't go to your account, go and foudn a way that go to your account by  that, till that time use mnuall search
