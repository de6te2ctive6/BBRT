
#!/bin/bash

# ViewDNS API key
API_KEY="API_HERE"

read -rp "Enter the path of ipseprator_output.txt: " input_file

if [[ ! -f "$input_file" ]]; then
    echo "File not found!"
    exit 1
fi

output_file="viewdns_output.txt"
temp_file=$(mktemp)
response_file=$(mktemp)

> "$output_file"
> "$temp_file"

while IFS= read -r ip || [[ -n "$ip" ]]; do
    ip=$(echo "$ip" | xargs)
    [[ -z "$ip" ]] && continue

    echo
    echo "Checking IP: $ip"

    http_code=$(curl -sS -G \
        "https://api.viewdns.info/reverseip/" \
        --data-urlencode "host=$ip" \
        --data-urlencode "apikey=$API_KEY" \
        --data-urlencode "output=json" \
        -o "$response_file" \
        -w "%{http_code}")

    if [[ $? -ne 0 ]]; then
        echo "[API ERROR] Connection failed for $ip"
        echo "API ERROR | $ip | Connection failed" >> "$output_file"
        continue
    fi

    # HTTP/API error codes
    if [[ "$http_code" != "200" ]]; then
        case "$http_code" in
            400) error="Invalid IP or request" ;;
            401) error="Invalid API key" ;;
            403) error="API access denied" ;;
            429) error="API query limit reached" ;;
            *)   error="HTTP error $http_code" ;;
        esac

        echo "[API ERROR] $ip - $error"
        echo "API ERROR | $ip | $error" >> "$output_file"
        continue
    fi

    # Detect JSON API errors
    if jq -e '.success == false or .error != null' \
        "$response_file" >/dev/null 2>&1; then

        error=$(jq -r '.error.message // .error // "Unknown API error"' \
            "$response_file")

        echo "[API ERROR] $ip - $error"
        echo "API ERROR | $ip | $error" >> "$output_file"
        continue
    fi

    # Detect plain-text API errors
    response_text=$(cat "$response_file")

    if [[ "$response_text" == *"Query limit reached"* ]]; then
        echo "[API ERROR] $ip - Query limit reached"
        echo "API ERROR | $ip | Query limit reached" >> "$output_file"
        continue
    fi

    if [[ "$response_text" == *"API key"* ]]; then
        echo "[API ERROR] $ip - API key problem"
        echo "API ERROR | $ip | API key problem" >> "$output_file"
        continue
    fi

    # Check whether a valid domains array exists
    if ! jq -e '.response.domains' "$response_file" >/dev/null 2>&1; then
        echo "[API ERROR] $ip - Unexpected API response"
        echo "API ERROR | $ip | Unexpected API response" >> "$output_file"
        continue
    fi

    # Extract hostnames
    hostnames=$(jq -r \
        '.response.domains[]?.name // empty' "$response_file" |
        sort -u)

    if [[ -z "$hostnames" ]]; then
        echo "[NO RESULTS] $ip - No hostname or domain found"
        echo "NO RESULTS | $ip | No hostname or domain found" >> "$output_file"
        continue
    fi

    echo "[SUCCESS] $ip - Hostnames found"

    while IFS= read -r hostname; do
        [[ -z "$hostname" ]] && continue

        echo "HOSTNAME | $hostname | IP: $ip" >> "$temp_file"

        domain=$(echo "$hostname" |
            awk -F. 'NF >= 2 {print $(NF-1)"."$NF}')

        if [[ -n "$domain" ]]; then
            echo "DOMAIN | $domain | IP: $ip" >> "$temp_file"
        fi

    done <<< "$hostnames"

done < "$input_file"

{
    echo
    echo "HOSTNAMES:"
    grep '^HOSTNAME' "$temp_file" | sort -u

    echo
    echo "DOMAINS:"
    grep '^DOMAIN' "$temp_file" | sort -u

} >> "$output_file"

rm -f "$temp_file" "$response_file"

echo
echo "Finished! Results saved to $output_file"
