Requiement:
sudo apt install curl jq

Use the bash file:
chmod +x viewdns.sh
./viewdns_api.sh