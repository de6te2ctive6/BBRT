if want add any switches just add in this line:
["nmap", "-R", "-sC", "-sV", "-sT", "-O", "-p", port, ip]

