
import subprocess
import os

file_path = input("Enter the path of httpxsep output: ").strip()

if not os.path.isfile(file_path):
    print("File not found!")
    exit()

with open(file_path, "r") as file:
    targets = [line.strip() for line in file if line.strip()]

if not targets:
    print("Input file is empty!")
    exit()

limit_input = input(
    "How many IPs do you want to scan? (Press Enter for all): "
).strip()

if limit_input:
    try:
        limit = int(limit_input)

        if limit <= 0:
            print("Please enter a positive number!")
            exit()

        targets = targets[:limit]

    except ValueError:
        print("Invalid number!")
        exit()

output_file = "nmap_httpxsep_output.txt"

with open(output_file, "w") as output:
    for index, target in enumerate(targets, start=1):
        try:
            ip, port = target.rsplit(":", 1)

            print(
                f"\n[{index}/{len(targets)}] "
                f"Scanning {ip}:{port}..."
            )

            result = subprocess.run(
                ["nmap", "-R", "-sC", "-p", port, ip],
                capture_output=True,
                text=True
            )

            output.write(f"\n{'=' * 60}\n")
            output.write(f"Target: {target}\n")
            output.write(f"{'=' * 60}\n")
            output.write(result.stdout)

            if result.stderr:
                output.write(result.stderr)

        except ValueError:
            print(f"Invalid format: {target}")

print("\nScanning completed!")
print(f"Scanned: {len(targets)} targets")
print(f"Output saved to: {output_file}")
