
import re

filename = input("Enter the path of httpx output file: ")

normal = []
abnormal = []

with open(filename, "r") as file:
    for line in file:
        line = line.strip()

        if not line:
            continue

        match = re.search(
            r'(https?://)?(\d{1,3}(?:\.\d{1,3}){3})(?::(\d+))?',
            line
        )

        if not match:
            continue

        protocol, ip, port = match.groups()

        if port:
            normal.append(f"{ip}:{port}")
        elif protocol == "http://":
            normal.append(f"{ip}:80")
        elif protocol == "https://":
            normal.append(f"{ip}:443")
        else:
            abnormal.append(ip)

with open("httpxsep_output.txt", "w") as file:
    for item in normal:
        file.write(item + "\n")

    if abnormal:
        file.write("\n# Abnormal format\n")
        for item in abnormal:
            file.write(item + "\n")

print("\nDone! Output saved to httpxsep_output.txt")
