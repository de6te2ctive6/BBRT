
#!/usr/bin/env python3

def main():
    # Ask for Masscan output file
    file_path = input("Enter masscan output file path: ").strip()

    results = []

    try:
        with open(file_path, "r") as f:
            for line in f:
                line = line.strip()

                # Skip comments and empty lines
                if not line or line.startswith("#"):
                    continue

                parts = line.split()

                # Expected format:
                # open tcp 80 192.168.1.1 123456789
                if len(parts) < 4:
                    continue

                port = parts[2]
                ip = parts[3]

                results.append(f"{ip}:{port}")

    except FileNotFoundError:
        print("File not found.")
        return

    # Remove duplicates while preserving order
    results = list(dict.fromkeys(results))

    # Save to file
    with open("massfill_output.txt", "w") as f:
        for item in results:
            f.write(item + "\n")

    print(f"Done! {len(results)} targets saved to massfill_output.txt")


if __name__ == "__main__":
    main()
